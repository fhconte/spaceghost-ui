'use client'

import React, { useEffect } from 'react'
import { colors } from '@ecs-ds-web/tokens'

export type DSButtonSizes = 'small' | 'medium' | 'large'
export interface DSButtonProps {
  label: string
  id: string
  onClick: () => void
  variant?: 'contained' | 'outlined'
  disabled?: boolean
  className?: string
  children?: React.ReactNode
  size?: DSButtonSizes
}

export const DSButton: React.FC<DSButtonProps> = ({
  label,
  onClick,
  variant = 'contained',
  disabled = false,
  id,
  size = 'medium',
  className = '',
  children,
  ...rest
}) => {
  const baseClasses = `button ${variant === 'outlined' && 'button-outlined'}`
  const sizeClass = `button-${size}`

  // useEffect(() => console.log('Test useEffect'), [])

  return (
    <button
      type="button"
      id={id}
      className={`${baseClasses} ${sizeClass} ${className}`}
      aria-label={label}
      data-testid="test-button"
      onClick={onClick}
      disabled={disabled}
      style={{
        backgroundColor: colors.mainPink60,
        color: 'white',
        padding: getSizePadding(size),
        borderRadius: '0.6rem',
        border: 'none',
        cursor: 'pointer',
        fontSize: '1rem',
      }}
      {...rest}
    >
      {children ? children : label}
    </button>
  )
}

const getSizePadding = (size: DSButtonSizes) => {
  switch (size) {
    case 'small':
      return '0.5rem 1rem'
    case 'large':
      return '1.5rem 3rem'
    default:
      return '1rem 2rem'
  }
}
