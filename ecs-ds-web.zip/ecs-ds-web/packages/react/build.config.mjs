import { defineConfig } from 'rollup'
import typescript from '@rollup/plugin-typescript'
import commonjs from '@rollup/plugin-commonjs'
import nodeResolve from '@rollup/plugin-node-resolve'
import terser from '@rollup/plugin-terser'
import preserveDirectives from 'rollup-plugin-preserve-directives'

export default defineConfig({
  input: './src/index.tsx',
  output: [
    {
      format: 'es',
      dir: 'dist',
      sourcemap: true,
      preserveModules: true,
    },
    {
      format: 'cjs',
      dir: 'dist',
      preserveModules: true,
    },
  ],
  plugins: [
    preserveDirectives(),
    terser(),
    typescript({
      outDir: 'dist',
    }),
    nodeResolve(),
    commonjs(),
  ],
  external: ['react'],

  // Ignore warnings when using "use client" directive
  onwarn(warning, warn) {
    if (warning.code !== 'MODULE_LEVEL_DIRECTIVE') {
      warn(warning)
    }
  },
})
