import { defineConfig } from 'rollup'
import typescript from '@rollup/plugin-typescript'
import commonjs from '@rollup/plugin-commonjs'

export default defineConfig({
  input: './src/index.ts',
  output: [
    {
      format: 'es',
      file: 'dist/index.mjs',
      sourcemap: true,
    },
    {
      format: 'cjs',
      file: 'dist/index.js',
    },
  ],
  plugins: [
    typescript({
      outDir: 'dist',
    }),
    commonjs(),
  ],
  watch: {
    include: 'src/**',
  },
})
