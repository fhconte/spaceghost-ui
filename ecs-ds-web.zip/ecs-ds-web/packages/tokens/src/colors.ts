import { primitiveColors } from './colors-primitive'

export const colors = { ...primitiveColors }
