import { defineConfig } from 'rollup'
import typescript from '@rollup/plugin-typescript'
import commonjs from '@rollup/plugin-commonjs'
import resolve from '@rollup/plugin-node-resolve'

export default defineConfig({
  input: './src/index.ts',
  output: [
    {
      format: 'es',
      file: 'dist/index.mjs',
    },
    {
      format: 'cjs',
      file: 'dist/index.js',
    },
  ],
  plugins: [
    typescript({
      outDir: 'dist',
    }),
    resolve({ browser: false }),
    commonjs(),
  ],
})
