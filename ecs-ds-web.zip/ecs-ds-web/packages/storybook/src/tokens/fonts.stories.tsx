import React from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import { fonts } from '@ecs-ds-web/tokens'
import { TokensGrid } from '../components/TokensGrid'

const FontsPage: React.FC = () => <TokensGrid tokens={fonts} />

const meta = {
  title: 'Tokens/Fonts',
  component: FontsPage,
} satisfies Meta<typeof FontsPage>

export default meta
type Story = StoryObj<typeof meta>
export const Fonts: Story = {}
