import React from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import { colors } from '@ecs-ds-web/tokens'
import { getContrast } from 'polished'

const ColorsGrid = () =>
  Object.entries(colors).map(([key, color]) => {
    return (
      <div key={key} style={{ backgroundColor: color, padding: '2rem' }}>
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            fontFamily: 'Nunito Sans',
            color: getContrast(color, '#FFF') < 3.5 ? '#000' : '#FFF',
          }}
        >
          <strong>${key}</strong>
          <span>{color}</span>
        </div>
      </div>
    )
  })

const ColorsPage: React.FC = () => <ColorsGrid />

const meta = {
  title: 'Tokens/Colors',
  component: ColorsPage,
} satisfies Meta<typeof ColorsPage>

export default meta
type Story = StoryObj<typeof meta>
export const Colors: Story = {}
