import type { Meta, StoryObj } from '@storybook/react'
import { fn } from '@storybook/test'
import { DSButton, type DSButtonProps } from '@ecs-ds-web/react'

const meta = {
  title: 'Components/DSButton',
  component: DSButton,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {},
  args: {
    onClick: fn(),
  },
} satisfies Meta<DSButtonProps>

export default meta
type Story = StoryObj<typeof meta>

export const Primary: Story = {
  args: {
    label: 'Primary',
  },
}

export const Secondary: Story = {
  args: {
    label: 'Secondary',
  },
}
