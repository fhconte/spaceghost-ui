# ECS-DS-WEB

## Install deps

`npm i`

## Run dev watch mode

`npm run dev`

## Run build

`npm run build`

## Execute a clean install

`npm run clean install`
